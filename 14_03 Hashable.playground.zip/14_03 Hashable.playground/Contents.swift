// Hashable
// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 14 (Q2 2021) video 02
//  by Steven Lipton (C)2021, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//  For more code, go to http://bit.ly/AppPieGithub

import Foundation

enum Sizes{
    case small,medium,large
}
let pizzaDict = ["Cheese":7.99,"Pepperoni":8.99]
let names:Set<String> = ["Cheese","Pepperoni"]

struct Pizza{
    var name:String
    var price:Double = 0.00
}

let pizzas:Set<Pizza> = [Pizza(name:"Cheese",price:7.99),Pizza(name:"Pepperoni",price:8.99)]

for item in names{
    print(item)
}
